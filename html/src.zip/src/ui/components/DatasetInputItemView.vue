<template>
  <div class="row mt-2">
    <div class="col-4">
      <select v-model="item.dataset" v-on:change="$emit('changed')"  id="new-item-dataset" class="form-select form-select-sm">
        <option v-for="dataset in datasets">{{ dataset }}</option>
      </select>
    </div>
    <div class="col-6">
      <input id="new-item-term" placeholder="E.g. term1+term2" v-model:value="item.term" v-on:change="$emit('changed')" v-on:keyup="$emit('typedInput')" style="width: 100%;" class="form-input form-input-sm">
    </div>
    <div class="col-2">
      <button class="btn btn-secondary btn-sm" v-on:click="$emit('remove')">x</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "DatasetInputItemView",
  props: ['datasets', 'item'],
}
</script>
