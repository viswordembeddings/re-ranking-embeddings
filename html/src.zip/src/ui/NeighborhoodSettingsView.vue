<template>
  <div>
    <div class="container">
      <div class="row">
        <h4>Settings</h4>
      </div>
      <div class="row">
        <div class="container">
          <div class="row">
            <span>Colormap</span>
          </div>
          <div class="row pt-2 px-2">
            <select v-model.number="settings.view.color_scale" id="view-scolor-scale" type="number" class="form-select form-select-sm">
              <option value="original">original</option>
              <option value="flare">flare</option>
              <option value="crest">crest</option>
              <option value="cividis">cividis</option>
            </select>
          </div>
          <div class="row pt-2">
            <span>Quantile</span>
          </div>
          <div class="row pt-2 px-2">
          <select v-model.number="settings.view.quantile" id="view-quantile" type="number" class="form-select form-select-sm">
            <option value="-1">None</option>
            <option value="10">Original Q2 (acc. paper)</option>
            <option value="2">25%</option>
            <option value="3">50% (Median)</option>
            <option value="4">75%</option>
          </select>
          </div>
          <div class="row pt-2">
            <span>Neighbors ({{ numNeighbors }})</span>
          </div>
          <div class="row pt-2 px-2">
            <input v-model.number="numNeighbors" type="range" class="form-range" min="5" max="15" id="neighbor-range">
          </div>
          <div class="row pt-2">
            <span>
              <span>Extended Terms</span> <input type="checkbox" id="checkbox" v-model="showExtendedTerms" class="form-check-input" style="margin-left: 5px;">
            </span>
          </div>
          <div class="row pt-2">
            <span>
              <button class="btn btn-secondary btn-sm" v-on:click="termSelectAll">Select All Terms</button>
              <button class="btn btn-secondary btn-sm" v-on:click="termUnselectAll">Clear Term Selection</button>
              <button class="btn btn-secondary btn-sm" v-on:click="autoZoom">Auto Zoom</button>
            </span>
          </div>
        </div>
      </div>
      <div class="row pt-2">
        <h4>Datasets</h4>
      </div>
      <div class="row">
        <div class="container">
          <div class="row">
            <div class="span2">
              <div class="progress">
                <div v-bind:class="{'progress-bar-striped progress-bar-animated bg-primary': this.status.processing, 'bg-secondary': !this.status.processing}" class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
              </div>
            </div>
          </div>
          <dataset-input-item-view
              v-for="(item, index) in this.settings.selections"
              v-bind:datasets="datasetAvailable"
              v-bind:key="item.id"
              v-bind:item="item"
              v-on:remove="removeItem(index)"
              v-on:changed="changedItem(index)"
              v-on:typedInput="typedInputItem(index)"
          ></dataset-input-item-view>
          <div class="row mt-2">
            <div class="col-12">
              <button class="btn btn-primary btn-sm" v-on:click="addNewItem">Add new Dataset</button>
              <button class="btn btn-secondary btn-sm" v-on:click="clearDatasets">Clear</button>
              <button class="btn btn-secondary btn-sm" v-on:click="loadDemoDatasets">Load "gay' demo</button>
            </div>
          </div>
          <div class="row mt-2 mb-4">
            <div class="col-12">
              <b>Word Suggestions: </b>{{ wordSuggestions }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import DatasetInputItemView from "./components/DatasetInputItemView.vue";

export default {
  name: "NeighborhoodSettingsView",
  props: ['datasets', 'processor', 'settings', 'status'],
  components: {
    DatasetInputItemView
  },
  created() {
    // console.log(this.datasets.list());
    // console.log(this.settings.neighbors);
  },
  data: function () {
    return {
      itemIdCounter: 0,
      wordSuggestions: "-",
      lastItem: {
        dataset: '',
        term: ''
      },
    }
  },
  computed: {
    showExtendedTerms: {
      get() {
        return this.settings.extendedTerms
      },
      set(newValue) {
        this.settings.extendedTerms = newValue;

        // poke processor to rebuild data
        this.processor.rebuild('extendedTerms', this.settings);
      }
    },
    numNeighbors: {
      get() {
        return this.settings.neighbors
      },
      set(newValue) {
        if (newValue >= 0 && newValue <= 15) {
          this.settings.neighbors = newValue
        }

        // poke processor to rebuild data
        this.processor.rebuild('neighbors', this.settings);
      }
    },
    datasetAvailable : {
      get() {
        return this.datasets.list();
      }
    }
  },
  watch: {
    datasets: {
      handler(newVal, oldVal) {
        this.lastItem = {
          dataset: this.datasets.list()[0],
          term: ''
        }

        // random selection
        let terms = this.datasets.terms();
        this.wordSuggestions = [...Array(15).keys()].map(v => terms[Math.floor(Math.random()*terms.length)]).join(', ');
        // this.wordSuggestions = this.datasets.terms().slice(0, 15).join(', ');
      },
      deep: true, // fire if any of child elements changes
    }
  },
  methods: {
    // takes the value of whatever input the user typed in
    // and extracts the last active term searches for terms
    // in all datasets which include this active term
    // this is suggested back to the user for valid inputs
    typedInputItem: function(index) {
      let activeTerm = this.settings.selections[index].term;

      let lastWordStart = activeTerm.lastIndexOf('+');
      if (lastWordStart < 0)
        lastWordStart = activeTerm.lastIndexOf('-');
      if (lastWordStart < 0)
        lastWordStart = 0;
      else
        lastWordStart += 1;

      let lastWord = activeTerm.substring(lastWordStart, activeTerm.length);

      if (lastWord.length > 0) {
        let foundTerms = this.datasets.terms().filter(w => w.includes(lastWord));
        this.wordSuggestions = foundTerms.slice(0, 15).join(', ');
      } else {
        // random selection
        let terms = this.datasets.terms();
        this.wordSuggestions = [...Array(15).keys()].map(v => terms[Math.floor(Math.random()*terms.length)]).join(', ');
      }
    },
    // adds a new item to the dataset list
    // uses the last changed item as a template
    addNewItem: function () {
      this.settings.selections.push({
        id: this.itemIdCounter,
        dataset: this.lastItem.dataset,
        term: this.lastItem.term
      })

      this.itemIdCounter += 1;

      // poke processor to rebuild data
      this.processor.rebuild('terms', this.settings);
    },
    // fired when an item was changed
    changedItem: function (index) {
      this.lastItem = {
        dataset: this.settings.selections[index].dataset,
        term: this.settings.selections[index].term
      }

      // poke processor to rebuild data
      this.processor.rebuild('terms', this.settings);
    },
    // fired when an item was removed
    removeItem: function (index) {
      this.settings.selections.splice(index, 1)

      // poke processor to rebuild data
      this.processor.rebuild('terms', this.settings);
    },
    loadDemoDatasets: function () {
      this.settings.selections = [
          { dataset: '1800', term: 'gay' },
          { dataset: '1810', term: 'gay' },
          { dataset: '1820', term: 'gay' },
          { dataset: '1830', term: 'gay' },
          { dataset: '1840', term: 'gay' },
          { dataset: '1850', term: 'gay' },
          { dataset: '1860', term: 'gay' },
          { dataset: '1870', term: 'gay' },
          { dataset: '1880', term: 'gay' },
          { dataset: '1890', term: 'gay' },
          { dataset: '1900', term: 'gay' },
          { dataset: '1910', term: 'gay' },
          { dataset: '1920', term: 'gay' },
          { dataset: '1930', term: 'gay' },
          { dataset: '1940', term: 'gay' },
          { dataset: '1950', term: 'gay' },
          { dataset: '1960', term: 'gay' },
          { dataset: '1970', term: 'gay' },
          { dataset: '1980', term: 'gay' },
          { dataset: '1990', term: 'gay' },
      ];

      // poke processor to rebuild data
      this.processor.rebuild('terms', this.settings);
    },
    clearDatasets: function () {
      this.settings.selections = [];

      // poke processor to rebuild data
      this.processor.rebuild('terms', this.settings);
    },
    termSelectAll: function () {
      this.settings.view.selected_terms = this.datasets.terms();
    },
    termUnselectAll: function () {
      this.settings.view.selected_terms = [];
    },
    autoZoom: function () {
      this.settings.view.auto_zoom = true;
    },
  }
}
</script>

<style scoped>

</style>