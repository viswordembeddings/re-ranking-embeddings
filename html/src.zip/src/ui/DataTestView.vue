<template>
<div>
  <div>this.g.datasets = this.g.datasets</div>
  <div>this.g.settings.neighborhood = {{ this.g.settings.neighborhood }}</div>
</div>
</template>

<script>
export default {
  name: "DataTestView.vue",
  props: ['g']
}
</script>

<style scoped>

</style>