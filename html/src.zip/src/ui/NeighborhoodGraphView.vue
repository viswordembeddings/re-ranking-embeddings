<!--
Functionalities:
 > By default, we choose the terms value of the next dataset in the row to color
    - The last dataset we color black
    - If a word is not present in the next dataset it is colored black instead.
 > When a dataset / row is selected this row is colored linear from low to high similarity.
    - All other datasets items are colored using the similarity value of the selected row.
    - If a word is not present in the selected dataset it is colored black instead.
    - Selected dataset name is colored red
 > Quantile: Incorrect implementation in the original paper, see notes below in the implementation.
 > When a word is selected we draw lines between the previous and following same word
 > When hovering over a dataset all words are shown
-->

<template>
  <div id="neighborhood-graph"></div>
</template>

<script>
import * as d3 from "d3";

import colors from "d3-scale-chromatic/src/colors";
function ramp(range) {
  const n = range.length;
  return function(t) {
    return range[Math.max(0, Math.min(n - 1, Math.floor(t * n)))];
  };
}

// original color map in linear scale
const cOriginalColors = ['#c7e9b4','#c7e9b4','#c7e9b4','#c7e9b4','#7fcdbb', '#41b6c4', '#1d91c0', '#225ea8', '#253494', '#081d58']
const cOriginal = d3.scaleLinear().domain([...Array(cOriginalColors.length + 1).keys()].map(v => v / cOriginalColors.length)).range(cOriginalColors);
// color maps from extracted from seaborn
const cFlare = ramp(colors("edb081edaf80edae7fedad7fedac7eedab7eecaa7deca97ceca87ceca77beca67beca57aeca479eca379eca278eca178eca077ec9f76eb9e76eb9d75eb9c75eb9b74eb9a73eb9973eb9972eb9872eb9771ea9671ea9570ea946fea936fea926eea916eea906dea8f6cea8e6ce98d6be98c6be98b6ae98a6ae98969e98868e98768e98667e88567e88466e88366e88265e88165e88064e87f64e77e63e77d63e77c63e77b62e77a62e67961e67861e67760e67660e67560e5745fe5735fe5725fe5715ee5705ee46f5ee46e5ee46d5de46c5de36b5de36a5de3695de3685ce2675ce2665ce2655ce1645ce1635ce1625ce0615ce0605ce05f5cdf5f5cdf5e5cde5d5cde5c5cde5b5cdd5a5cdd595cdc585cdc575cdb565ddb565dda555dda545dd9535dd9525ed8525ed7515ed7505ed64f5fd64f5fd54e5fd44d60d44c60d34c60d24b60d24a61d14a61d04962d04962cf4862ce4763cd4763cc4663cc4664cb4564ca4564c94465c84465c84365c74366c64366c54266c44267c34167c24167c14168c14068c04068bf4069be3f69bd3f69bc3f69bb3f6aba3e6ab93e6ab83e6bb73d6bb63d6bb53d6bb43d6bb33c6cb23c6cb13c6cb13c6cb03b6daf3b6dae3b6dad3b6dac3a6dab3a6daa3a6ea93a6ea8396ea7396ea6396ea5396ea4386fa3386fa2386fa1386fa1376fa0376f9f376f9e37709d36709c36709b36709a36709935709835709735709635709534709434709434719334719233719133719033718f33718e32718d32718c32718b32718a3171893171883171873171873171863071853071843071833070822f70812f70802f707f2f707e2f707d2e707c2e707b2e707a2e70792e6f782e6f772d6f762d6f752d6f752d6f742d6e732c6e722c6e712c6e702c6e6f2c6d6e2c6d6d2b6d6c2b6d6b2b6c6a2b6c692b6c682a6c672a6b662a6b652a6b642a6a642a6a63296a62296a6129696029695f29695e28685d28685c28685b28675a27675927675827665827665727665626665526655426655326655225645125645025644f24634f24634e24634d24634c23624b2362"));
const cCrest = ramp(colors("a5cd90a4cc90a3cc91a2cb91a0cb919fca919eca919dc9919cc8919bc8919ac79199c79198c69196c69195c59194c59193c49192c49191c39190c3918fc2918ec2918dc1918bc1918ac09189bf9188bf9187be9186be9185bd9184bd9182bc9181bc9180bb917fbb917eba917dba917cb9917bb99179b89178b89177b79176b79175b69074b69073b59072b49071b49070b3906fb3906eb2906db2906cb1906bb1906ab09069b09068af9067ae9066ae9065ad9064ad9063ac9062ac9062ab9061aa9060aa905fa9905ea9905da8905ca8905ba7905ba6905aa69059a59058a59057a49057a49056a39055a29054a29053a19053a19052a090519f90509f90509e904f9e904e9d904e9d904d9c904c9b904b9b904b9a8f4a9a8f49998f49988f48988f47978f47978f46968f45958f45958f44948f43948f43938f42928f41928f41918f40918f40908e3f8f8e3e8f8e3e8e8e3d8e8e3c8d8e3c8c8e3b8c8e3a8b8e3a8b8e398a8e388a8e38898e37888e37888d36878d35878d35868d34858d33858d33848d32848d31838d31828d30828d2f818d2f818d2e808d2d808c2d7f8c2c7e8c2c7e8c2b7d8c2a7d8c2a7c8c297b8c287b8c287a8c277a8c27798c26788c25788c25778c24778b24768b23758b23758b22748b22748b21738b21728b20728b20718b20718b1f708b1f6f8a1e6f8a1e6e8a1e6d8a1e6d8a1d6c8a1d6c8a1d6b8a1d6a8a1d6a8a1c69891c68891c68891c67891c66891c66891c65891c64881c64881c63881d63881d62881d61881d61871d60871d5f871d5f871e5e871e5d861e5d861e5c861e5b861f5b861f5a851f59851f5985205885205784205784205684215584215583215483225383225283225282225182235082235081234f81244e81244e80244d80254c80254c7f254b7f254a7f26497e26497e26487e27477d27477d27467c27457c28457c28447b28437b28427a29427a29417a2940792940792a3f782a3e782a3d782a3d772a3c772a3b762b3b762b3a762b39752b38752b38752b37742b36742c35742c35732c34732c33732c32722c31722c3172"));

function _find_color_scale_by_name(name) {
  if (name === 'original') {
    return cOriginal;
  } else if (name === 'flare') {
    return cFlare;
  } else if (name === 'cividis') {
    return function (v) {
      return d3.interpolateCividis(1 - v);
    }
  } else {
    return cCrest;
  }
}

function _draw_link_path(d, graph) {
    let diff =  graph.ctx.scaleSimilarity(d.linkedTermValue) - graph.ctx.scaleSimilarity(d.termValue);
    let baseline_x = graph.ctx.g_style.margin.left + graph.ctx.scaleSimilarity(d.termValue);
    let baseline_y = graph.ctx.g_style.margin.top;
    baseline_y += graph.ctx.g_style.bar.height * d.dsIdx;

    return d3.line()([[baseline_x, baseline_y + graph.ctx.g_style.bar.height/2], [baseline_x + diff, baseline_y + graph.ctx.g_style.bar.height*1.5]]);
}

function svg_init(graph, settings) {
    graph.svg.attr('width', graph.width).attr('height', graph.height);

    const svg = graph.svg;
    const ctx = graph.ctx;
    const width = graph.width;

    /** Define global graph variables **/
    let g_style = {
      zoom: {
        max_scale: 50
      },
      global: {
        color_bar: {
          height: 20
        }
      },
      bar: {
        height: 35,
        line_height: 15,
        line_color: '#000000',
        quantile_color: 'lightgrey'
      },
      term: {
        size: 5,
      }
    }

    g_style.margin = {top: 45, right: 25, bottom: 25, left: 70};
    g_style.bar.length = width - g_style.margin.left - g_style.margin.right;
    ctx.g_style = g_style;

    // Init scale
    ctx.scaleSimilarityDefault = d3.scaleLinear()
        .domain([0, 1])
        .range([0, g_style.bar.length]);
    ctx.scaleSimilarity = ctx.scaleSimilarityDefault;

    // Init zoom
    ctx.zoom = d3.zoom()
      .scaleExtent([1, g_style.zoom.max_scale])
      .on("zoom", function (e) {
        action_event_zoomed(graph, settings, e)
      });
    svg.call(ctx.zoom);

    // add color gradient definition element
    ctx.linear_gradient_group = svg
        .append("def")
        .append("linearGradient")
          .attr('id', 'colorgradient');

    // Element: zoombar
    ctx.zoombar = svg.append("rect")
            .attr("transform", `translate(${g_style.margin.left}, 0)`)
            .attr("width", g_style.bar.length)
            .attr("height", g_style.global.color_bar.height / 2)
            .attr("class", "zoombar")
            .attr('fill', 'lightgrey');
    ctx.zoombar_left = svg.append("rect")
            .attr("transform", `translate(${g_style.margin.left}, 0)`)
            .attr("width", 0)
            .attr("height", g_style.global.color_bar.height / 2)
            .attr("class", "zoombar")
            .attr('fill', 'darkgrey');
    ctx.zoombar_right = svg.append("rect")
            .attr("transform", `translate(${g_style.margin.left + 0}, 0)`)
            .attr("width", 0)
            .attr("height", g_style.global.color_bar.height / 2)
            .attr("class", "zoombar")
            .attr('fill', 'darkgrey');

    // Element: colorbar
    ctx.colorbar = svg.append("rect")
            .attr("transform", `translate(${g_style.margin.left}, ${ g_style.global.color_bar.height })`)
            .attr("width", g_style.bar.length)
            .attr("height", g_style.global.color_bar.height)
            .attr("class", "colorbar")
            .attr('fill', 'url(#colorgradient)');

    // Group datasets background
    ctx.dataset_collection = svg.append("g")
        .attr("class", "dataset_collection");

    // Group lines
    ctx.linkgroup_collection = svg.append("g")
        .attr("class", "linkgroup_collection");

    // Group datasets foreground
    ctx.dataset_fg_collection = svg.append("g")
        .attr("class", "dataset_fg_collection");


    svg.on('click', function() {
       settings.view.selected_terms = [];
   });
}

function action_event_zoomed(graph, settings, zoomevent) {

    // deactivate auto zoom
    settings.view.auto_zoom = false;

    // rescale axis
    graph.ctx.scaleSimilarity = zoomevent.transform.rescaleX(graph.ctx.scaleSimilarityDefault);

    function calculate_datapoint_offset_x(datapoint, idx) {
      let value = datapoint.value;
      return graph.ctx.scaleSimilarity(value);
    }

    const domainStart = Math.max(graph.ctx.scaleSimilarity.domain()[0], 0);
    const domainEnd = Math.min(graph.ctx.scaleSimilarity.domain()[1], 1);

    // Hide data points that would be rendered outside of the graph borders
    graph.ctx.datapoint_group
        .attr('transform', (d, idx) => `translate(${calculate_datapoint_offset_x(d, idx)}, 0)`)
        .style('visibility', function (d) {
          if (d.value < domainStart || d.value > domainEnd) {
            return "hidden";
          } else {
            return "visible";
          }
        });

    // Hide paths between data points when one data point would be rendered utside of the graph borders
    graph.ctx.links
        .attr("d", (d) => _draw_link_path(d, graph))
        .style('visibility', function (d) {
          if (d.termValue < domainStart || d.termValue > domainEnd || d.linkedTermValue < domainStart || d.linkedTermValue > domainEnd) {
            return "hidden";
          } else {
            return "visible";
          }
        });

    // update quantile bar length
    graph.ctx.dataset_group
        .select('.quantile_background')
        .attr('width', (dataset, idx) => {
          let value = dataset.quantile;
          if (value > 0) {
            return graph.ctx.scaleSimilarity(value);
          } else {
            return 0;
          }
        })

    // update zoombar indicator
    graph.ctx.zoombar_left.attr("width", graph.ctx.g_style.bar.length * domainStart);
    graph.ctx.zoombar_right.attr("transform", `translate(${Math.floor(graph.ctx.g_style.margin.left + graph.ctx.g_style.bar.length * domainEnd)}, 0)`);
    graph.ctx.zoombar_right.attr("width", Math.floor(graph.ctx.g_style.bar.length * (1 - domainEnd)));
}

function action_dataset_mouseover(graph, enters, eventobj) {
  const domainStart = Math.max(graph.ctx.scaleSimilarity.domain()[0], 0);
  const domainEnd = Math.min(graph.ctx.scaleSimilarity.domain()[1], 1);

  if (enters) {
    d3.select(eventobj.parentNode).selectAll('.label-term, .label-term-bg')
      .style('display', function (d) {
        if (d.value < domainStart || d.value > domainEnd) {
          return "none";
        } else {
          return "block";
        }
      });
    d3.select(eventobj.parentNode).selectAll('.label-term-bg')
      .style('visibility', function (d) {
        if (d.value < domainStart || d.value > domainEnd) {
          return "hidden";
        } else {
          return "visible";
        }
      });
  } else {
    d3.select(eventobj.parentNode).selectAll('.label-term')
        .style("display", "none");
    d3.select(eventobj.parentNode).selectAll('.label-term-bg')
        .style("visibility", "hidden");
  }
}

function svg_render(graph, data, settings) {
    const svg = graph.svg;
    const ctx = graph.ctx;
    const g_style = graph.ctx.g_style;
    const tooltip = graph.tooltip;

    /* update global style based on settings */
    g_style.global.color_scale = _find_color_scale_by_name(settings.view.color_scale);
    let dynamicHeight = g_style.margin.top + g_style.bar.height * data.d.length + g_style.margin.bottom;
    graph.svg.attr('height', dynamicHeight);


    // calculate min and max value over all terms (of all datasets)
    let term_value_min = data.d.reduce((outd, dd) => {
      let mind = dd.terms.reduce((outt, dt) => Math.min(outt, dt.value), Number.MAX_SAFE_INTEGER);
      return Math.min(outd, mind);
    }, Number.MAX_SAFE_INTEGER);
    let term_value_max = data.d.reduce((outd, dd) => {
      let maxd = dd.terms.reduce((outt, dt) => Math.max(outt, dt.value), Number.MIN_SAFE_INTEGER);
      return Math.max(outd, maxd);
    }, Number.MIN_SAFE_INTEGER);

    // auto zoom if activated
    if (settings.view.auto_zoom) {
      let zoomStart = ctx.scaleSimilarityDefault(term_value_min)
      let zoomEnd = ctx.scaleSimilarityDefault(term_value_max);
      let width = g_style.bar.length;
      let scale = width / (zoomEnd - zoomStart);
      svg.call(ctx.zoom).transition()
        .duration(200)
        .call(
            ctx.zoom.transform,
            d3.zoomIdentity.scale(scale).translate(-zoomStart, 0)
        );
    }

    /** Create d3js view data structure (unroll settings and dataset into actual d3js data) **/

    let reference_dataset = data.d.find(ddataset => ddataset.name === settings.view.selected_dataset);
    let linkData = {};
    let d3data = data.d.map((ddataset, didx) => {

      // NOTE: Not sure what is going on here
      // we don't actually use the stats quantile values but instead we use the max value of the
      // extended!!! terms. In the comments in the original code it says nearest neighbors... This makes absolutely no sense?
      let quantileValue = 0;
      if (settings.view.quantile === 10) { // This is the original paper
        quantileValue = 1 - ddataset.terms.reduce((outt, dt) => (!dt.isExtendedTerm) ? Math.max(outt, 1 - dt.value) : outt, Number.MIN_SAFE_INTEGER);

      } else if (settings.view.quantile >= 0) { // This is using actual quantile values
        quantileValue = ddataset.stats[settings.view.quantile];
      }


      let isSelectedDataset = ddataset.name === settings.view.selected_dataset;
      let isLastDataset = data.d.length === (didx + 1);

      let terms = ddataset.terms.map(dterm => {
        let isExtendedTerm = dterm.isExtendedTerm;
        let term = dterm.term;
        let termValue = dterm.value;

        // by default we choose the terms value of the next dataset to color
        // except if its the last row OR we don't have a value for the term in the next dataset, then black
        let valueColor = -1;

        if (!isLastDataset) {
          let nextDataset = data.d[didx + 1];
          let nextDatasetTerm = nextDataset.terms.find(dterm => dterm.term === term)
          if (nextDatasetTerm !== undefined) {
            valueColor = nextDatasetTerm.value;

            if (settings.view.selected_terms.includes(term)) {

              if (!(term in linkData)) {
                linkData[term] = {'term': term, 'links': []};
              }
              linkData[term]['links'].push({'term': term, 'termValue': termValue, 'linkedTermValue': valueColor, 'dsIdx': didx});
            }
          }
        }

        // check if we have a selected reference dataset
        if (reference_dataset !== undefined) {
          // if yes and we are the reference just use the value
          if (isSelectedDataset) {
            valueColor = termValue;
          } else {
            // otherwise color this current term based on reference term value
            let referenceTermValue = reference_dataset.terms.find(dterm => dterm.term === term);
            if (referenceTermValue !== undefined) {
              valueColor = referenceTermValue.value;
            } else {
              // otherwise color black
              valueColor = -1;
            }
          }
        }

        return {
          value: termValue,
          valueColor: valueColor,
          term: term
        }
      });

      return {
        quantile: quantileValue,
        name: ddataset.name,
        termString: ddataset.termString,
        selected: isSelectedDataset,
        terms: terms
      }
    });

    let d3linkdata = Object.keys(linkData).map(function(key){
       return linkData[key];
    });

    /** Helpers **/
    function scale_term_value(value) {
      // calculate term position based on terms value
      // flipped and scaled by global min and max value
      return 1 - ((value - term_value_min) / (term_value_max - term_value_min))
    }

    /** DEFINITIONS **/

    // gradient color definitions
    let gradient_stops = 20;
    let gradient_offsets = [...Array(gradient_stops + 1).keys()].map(v => v / gradient_stops);

    ctx.linear_gradient_stop_group = ctx.linear_gradient_group
        .selectAll('stop')
        .data(gradient_offsets)

    ctx.linear_gradient_stop_group.exit().remove();

    let linear_gradient_stop_group_enter = ctx.linear_gradient_stop_group
        .enter()
        .append('stop')

    ctx.linear_gradient_stop_group = ctx.linear_gradient_stop_group.merge(linear_gradient_stop_group_enter);
    ctx.linear_gradient_stop_group
      .attr('offset', function(d) { return d; })
      .attr('stop-color', function(d) { return g_style.global.color_scale(1 - d); });


    /** DATASETS BACKGROUND */

    // select all datasets elements with selectAll (one .dataset by data entry)
    ctx.dataset_group = ctx.dataset_collection.selectAll(".dataset")
        .data(d3data, function(d) { return d.name;});

    // exit() is executed when datasets leaves the view
    ctx.dataset_group.exit().remove();

    // enter() is executed when new datasets enters the view
    let dataset_group_enter = ctx.dataset_group.enter()
                    .append("g").attr("class", "dataset");

    // Element: quantile background bar
    dataset_group_enter
            .append("rect")
            .attr("transform", `translate(0, ${g_style.bar.height / 2 - g_style.bar.line_height / 2})`)
            .attr("height", g_style.bar.line_height)
            .attr("class", "quantile_background")
            .attr("fill", g_style.bar.quantile_color)

    // Element: left line
    dataset_group_enter
            .append("rect")
            .attr("transform", `translate(0, ${g_style.bar.height / 2 - g_style.bar.line_height / 2})`)
            .attr("width", 1)
            .attr("height", g_style.bar.line_height)
            .attr("class", "left_line")
            .attr("fill", g_style.bar.line_color)

    // Element: center line
    dataset_group_enter
            .append("rect")
            .attr("transform", `translate(0, ${g_style.bar.height / 2})`)
            .attr("width", g_style.bar.length)
            .attr("height", "1")
            .attr("class", "center_line")
            .attr("fill", g_style.bar.line_color);

    // merge() the enter group and the update group, all changes
    // done on dataset_group are applied on enter and on update
    ctx.dataset_group = ctx.dataset_group.merge(dataset_group_enter);

    // calculate Y offset for each dataset
    function calculate_dataset_offset_y(idx) {
        let offset_total = g_style.margin.top;
        offset_total += g_style.bar.height * idx;
        return offset_total;
    }

    ctx.dataset_group.attr('transform', (d, idx) => {
        return `translate(${g_style.margin.left} ${calculate_dataset_offset_y(idx)})`;
    });

    // update quantile bar length
    ctx.dataset_group
        .select('.quantile_background')
        .attr('width', (dataset, idx) => {
          let value = dataset.quantile;
          if (value > 0) {
            return ctx.scaleSimilarity(value);
          } else {
            return 0;
          }
        })

    /** LINKS  */
    ctx.links_group = ctx.linkgroup_collection.selectAll(".linkgroup")
        .data(d3linkdata, function(d) { return d.term;});

    ctx.links_group.exit().remove();

    let links_group_enter = ctx.links_group.enter()
        .append("g").attr("class", "linkgroup").attr("id", (d) => "links_" + d.term);

    ctx.links_group = ctx.links_group.merge(links_group_enter);

    ctx.links = ctx.links_group.selectAll('.link')
        .data(function (d, idx) {
          return d.links;
        });

    ctx.links.exit().remove();

    let links_enter = ctx.links.enter()
        .append("path")
        .attr("class", "link")
        .attr("stroke", "black")
        .attr("stroke-width", 1)
        .attr("fill", "none");

    ctx.links = ctx.links.merge(links_enter);

    ctx.links.attr("d", (d) => _draw_link_path(d, graph));

    /** DATASETS FOREGROUND */
    ctx.dataset_fg_group = ctx.dataset_fg_collection.selectAll(".dataset_fg").data(d3data, function(d) { return d.name;});
    ctx.dataset_fg_group.exit().remove();
    let dataset_fg_group_enter = ctx.dataset_fg_group.enter().append("g").attr("class", "dataset_fg");

    // Element: dataset name
    dataset_fg_group_enter
            .append("text")
            .attr("font-size", 15) // FIXME: font size and position
            .attr("transform", `translate(-60, ${15-3 + g_style.bar.line_height / 2})`)
            .attr("class", "dataset_name")
            .attr("style", "cursor: pointer;")
            .on('click', function(e, d, i) {
              action_select_dataset(settings, d.name);
              e.stopPropagation();
            })
            .on("mouseenter", function(e, d, i) {
              action_dataset_mouseover(graph, true, this);
            })
            .on("mouseleave", function(e, d, i) {
              action_dataset_mouseover(graph, false, this);
            });

    // Element: dataset queryterm
    dataset_fg_group_enter
            .append("text")
            .attr("font-size", 10) // FIXME: font size and position
            .attr("transform", `translate(-60, ${15-3 + g_style.bar.line_height / 2 + 10})`)
            .attr("class", "dataset_termString")
            .attr("style", "cursor: pointer;")
            .on('click', function(e, d, i) {
              action_select_dataset(settings, d.name);
              e.stopPropagation();
            });

    ctx.dataset_fg_group = ctx.dataset_fg_group.merge(dataset_fg_group_enter);
    ctx.dataset_fg_group.attr('transform', (d, idx) => {
        return `translate(${g_style.margin.left} ${calculate_dataset_offset_y(idx)})`;
    });

    // update dataset name
    ctx.dataset_fg_group
        .select('.dataset_name')
        .attr('fill', (d, idx) => {
          return (d.selected) ? "red" : "black";
        })
        .text((d, idx) => {
          return d.name
        });

    // update termString
    ctx.dataset_fg_group
        .select('.dataset_termString')
        .attr('fill', (d, idx) => {
          return (d.selected) ? "red" : "black";
        })
        .text((d, idx) => {
          return d.termString
        });

    /** DATA POINTS */
    ctx.datapoint_group = ctx.dataset_fg_group.selectAll('.datapoint')
        .data(function (d, idx) {
          return d.terms;
        }, function(d) { return d.term;});

    ctx.datapoint_group.exit().remove();

    // enter() is executed when new datasets enters the view
    let datapoint_group_enter = ctx.datapoint_group.enter()
                    .append("g").attr("class", "datapoint");

    datapoint_group_enter.
            append("circle")
            .attr("cx", 0)
            .attr("cy", g_style.bar.height / 2)
            .attr("r", g_style.term.size)
            //.attr("height", g_style.term.size)
            .attr("class", "datapoint.circle")
            .style("cursor", "pointer")
            .on("mouseenter", function(e, d, i) {
              tooltip.html(d.term + '<br/>' + d.value);
              tooltip
                .style('left', e.pageX + g_style.term.size * 2 + 'px')
                .style('top', e.pageY + g_style.term.size * 2 + 'px')
                .style("opacity", 1.0);
            })
            .on("mouseleave", function(e, d, i) {
              tooltip.transition().duration(0).style("opacity", 0);
                  tooltip.html('');
                  tooltip.style('left', '0px')
                  .style('top', '0px')
                  .style("opacity", 0);
            })
            .on("click", function(e, d, i){
                action_select_term(settings, d.term);
                e.stopPropagation();
            });

          datapoint_group_enter
              .append("text")
              .attr("class", "label-term")
              .attr("transform", `rotate(-45) translate(0, ${g_style.bar.height*0.4})`)
              .attr("font-size", 13)
              .attr("fill", "black")
              .attr("alignment-baseline", "middle")
              .style("padding-left", "1em")
              .text(d => d.term)
              .call(getBB);

    function getBB(selection) {
        selection.each(function(d) {
            d.bbox = this.getBBox();
        });
    }

    datapoint_group_enter
        .insert("rect", "label-term")
        .attr("class", "label-term-bg")
        .attr("width", function(d) { return d.bbox.width * 1.1})
        .attr("height", function(d) { return d.bbox.height})
        .attr("transform", `rotate(-45) translate(-3, 0)`)
        .attr("rx", 2.5)
        .attr("ry", 2.5)
        .style("fill", "#f7f9ef")
        .style("stroke", "black")
        .style("visibility", "hidden")
        .lower();

    datapoint_group_enter.selectAll('.label-term').style("display", "none");

    ctx.datapoint_group = ctx.datapoint_group.merge(datapoint_group_enter);

    function calculate_datapoint_offset_x(datapoint, idx) {
      let value = datapoint.value;
      return ctx.scaleSimilarity(value);
    }

    function calculate_datapoint_color(datapoint, idx) {
      if (datapoint.valueColor > 0) {
        let value = datapoint.valueColor;
        return g_style.global.color_scale(scale_term_value(value));
      } else {
        return 'black'
      }
    }

    ctx.datapoint_group
        .attr('transform', (d, idx) => `translate(${calculate_datapoint_offset_x(d, idx)}, 0)`)
        .attr('fill', (d, idx) => calculate_datapoint_color(d, idx));
}

function action_select_dataset(settings, datasetName) {
  // if we select the same dataset again we unselect
  if (datasetName === settings.view.selected_dataset) {
    settings.view.selected_dataset = undefined;
  } else {
    settings.view.selected_dataset = datasetName;
  }
}


function action_select_term(settings, selectedTerm) {
  if (settings.view.selected_terms.includes(selectedTerm)) {
    settings.view.selected_terms = settings.view.selected_terms.filter(function(value, index, arr){
        return value !== selectedTerm;
    });
  } else {
    settings.view.selected_terms.push(selectedTerm);
  }
}

export default {
  name: "NeighborhoodGraphView",
  props: ["data", 'settings'],
  methods: {

  },
  mounted() {
    this.graph = {
        svg: d3.select('#neighborhood-graph').append('svg'),
        tooltip: d3.select('#neighborhood-graph').append('div')
          .attr('id', '#neighborhood-graph-tooltip')
          .style('position', 'absolute')
          .style('padding', '2px')
          .style('background-color', '#f7f9ef')
          .style('border', '1px solid black')
          .style('border-radius', '2.5px')
          .style('opacity', 0),
        width: 1000,
        ctx: {}
    };

    svg_init(this.graph, this.settings);
    svg_render(this.graph, this.data, this.settings);
  },
  watch: {
    settings: {
      handler(newVal, oldVal) {
        // when settings are changing we re-render the view
        svg_render(this.graph, this.data, this.settings);
      },
      deep: true, // fire if any of child elements changes
    },
    data: {
      handler(newVal, oldVal) {
        svg_render(this.graph, this.data, this.settings);
      },
      deep: true,
    },
  }
}
</script>

<style scoped>

</style>
