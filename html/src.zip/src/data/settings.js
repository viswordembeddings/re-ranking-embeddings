export class NeighborhoodSettings {

    neighbors = 10;
    extendedTerms = false;
    selections = [];

    // view sub-settings
    view = {
        color_scale: 'original',
        quantile: -1,
        selected_dataset: undefined,
        selected_terms: [],
        auto_zoom: false,
    }

    constructor() {

    }
}
