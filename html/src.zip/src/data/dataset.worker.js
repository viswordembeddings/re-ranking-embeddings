import {DatasetCollection, DataProcessor, NeighborhoodData} from "./dataset";

console.log("[WORKER] starting...");

const dsc = new DatasetCollection();
const nd = new NeighborhoodData();
const dp = new DataProcessor(dsc, nd);

onmessage = e => {
  const message = e.data;
  console.log(`[WORKER] onmessage:`);
  console.log(message);

  if (message.action === 'load') {
    dsc.load(function () {
      postMessage({
        action: 'datasetUpdate',
        datasets: dsc.list(),
        terms: dsc.terms()
      });
    });
  } else if (message.action === 'rebuild') {
    dp.rebuild(message.hint, message.settings, function () {
      postMessage({
        action: 'dataUpdate',
        data: nd.d,
        processId: message.processId
      });
    });
  }
};