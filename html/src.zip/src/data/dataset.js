import * as d3 from "d3";
import similarity from "compute-cosine-similarity";
import demo from './demo.json';

function l2norm( arr, clbk ) {
    let len = arr.length, t = 0, s = 1, r, val, abs, i;

    if ( !len ) {
        return null;
    }

    for ( i = 0; i < len; i++ ) {
        val = arr[ i ];
        abs = ( val < 0 ) ? -val : val;
        if ( abs > 0 ) {
            if ( abs > t ) {
                r = t / val;
                s = 1 + s*r*r;
                t = abs;
            } else {
                r = val / t;
                s = s + r*r;
            }
        }
    }

    return t * Math.sqrt( s );
}

function quantile(sorted, q) {
    const pos = (sorted.length - 1) * q;
    const base = Math.floor(pos);
    const rest = pos - base;
    if (sorted[base + 1] !== undefined) {
        return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
    } else {
        return sorted[base];
    }
}

export class Dataset {

    constructor(name, terms, data, dim) {
        this.name = name;
        this.terms = terms;
        this.data = data;
        this.dim = dim;
    }

    // construct a terms array from the term query
    // for each term we indicate the arithmetic operator
    _parseTermQuery(termquery) {
        let terms = [];

        let querychars = Array.from(termquery);
        let activeTerm = "";
        let activeOp = "=";
        for(let i = 0; i < querychars.length; i++) {
            let c = querychars[i];

            if (c === '+' || c === '-') {
                // complete active term
                if (activeTerm.length > 0) {
                    terms.push({
                        'op': activeOp,
                        'term': activeTerm
                    })
                }
                activeTerm = "";
                activeOp = c;
            } else {
                activeTerm += c;
            }
        }

        // complete last active term
        if (activeTerm.length > 0) {
            terms.push({
                op: activeOp,
                term: activeTerm
            })
        }

        return terms;
    }

    // build a single vector of all terms used in the query
    // arithmetic is allowed and the result is normalized
    buildTermsVec(termquery) {
        let terms = this._parseTermQuery(termquery);

        let termString = '';
        let termList = [];
        let vec = [...Array(this.dim).keys()].map(v => 0); // zero vector
        for (let t of terms) {
            let idx = this.terms.findIndex(o => o === t.term);

            // term not found, skip
            if (idx < 0)
                break;

            let start = idx * this.dim;
            let end = idx * this.dim + this.dim;

            let termVec = this.data.slice(start, end);

            // arithmetic vector calculation
            let m = 0.0;
            if (t.op === '=') {
                m = 1.0;
                termString += t.term;
            } else if (t.op === '+') {
                m = 1.0;
                termString += '+' + t.term;
            } else if (t.op === '-') {
                m = -1.0;
                termString += '-' + t.term;
            }

            termList.push(t.term);

            vec = vec.map((value, index) => {
                return value + m * termVec[index];
            });
        }

        if (termString.length > 0) {
            let normVec = vec;

            // Normalize
            let norm = l2norm(vec);
            if (norm > 0) {
                normVec = normVec.map(v => v / norm);
            }

            return {
                valid: true,
                vec: normVec,
                termString: termString,
                termList: termList
            }
        } else {
            return {
                valid: false
            }
        }
    }

    // calculates similarity to all other terms and returns
    // list of terms with decreasing distance
    findNeighbors(termsVecObj) {
        // if no term is found, no data is available
        if (!termsVecObj.valid)
            return {
                distances: [],
                termString: '',
                termList: []
            };

        let dists = [];
        for(let idx = 0; idx < this.terms.length; idx++) {
            let start = idx * this.dim;
            let end = idx * this.dim + this.dim;
            let vec = this.data.slice(start, end);
            let dist = 1.0 - similarity(Array.from(termsVecObj.vec), Array.from(vec));

            dists.push(dist);
        }

        let distArray = dists.map(((value, index) => ({t: this.terms[index], d: value})));

        let simArray = distArray.map((o => {
            // based on calculation in the ref impl
            let sim = ((1.0-o.d)+1.0) / 2.0;
            return {
                t: o.t,
                s: sim
            };
        }));

        // filter all nan values
        simArray = simArray.filter(o => !isNaN(o.s));

        // sort descending by similarity value
        simArray.sort(((a, b) => (b.s > a.s) ? 1 : -1));
        return {
            distances: simArray,
            termString: termsVecObj.termString,
            termList: termsVecObj.termList
        };
    }

}

export class DatasetCollection {

    constructor() {
        this.datasets = [];
        this.datasetTerms = [];
    }

    // loads terms list and all datasets
    load(callback) {
        let obj = this;
        // Load pre-curated embedding datasets
        let years = [
            '1800', '1810', '1820', '1830', '1840', '1850', '1860', '1870', '1880', '1890',
            '1900', '1910', '1920', '1930', '1940', '1950', '1960', '1970', '1980', '1990',
        ]

        d3.json("data/embeddings_terms.json").then(function(datasetTerms) {
            //console.log("embeddings_terms");
            //console.log(datasetTerms);
            obj.datasetTerms = datasetTerms;

            let datasets = years.map(y => `data/embeddings_m_${y}.f32.bin`);
            let datasetReqs = datasets.map(url => d3.buffer(url));
            Promise.all(datasetReqs).then(function(buffers) {
              buffers.forEach(((value, index) => {
                let name = years[index];
                let dataArray = new Float32Array(buffers[index]);
                let dim = 300;
                obj._add(new Dataset(name, datasetTerms, dataArray, dim));
              }));

            if (callback)
                callback();
            });
        });
    }

    _find(name) {
        return this.datasets.find(d => d.name === name);
    }

    _add(dataset) {
        this.datasets.push(dataset);
    }

    // list all dataset names
    list() {
        return this.datasets.map(d => d.name);
    }

    // list all available terms (over all datasets)
    terms() {
        return this.datasetTerms;
    }
}

export class NeighborhoodData {
    constructor() {
        this.d = [];
    }
}

export class DataProcessor {
    constructor(datasetCollection, neighborhoodData) {
        this._dc = datasetCollection;
        this._nd = neighborhoodData;
    }

    // rebuild neighborhood data based on settings and datasets
    // hint can be used to potentially improve / accelerate the processing
    rebuild(hint, settings, callback) {
        console.log('rebuild hint=' + hint);
        console.log(settings);

        // build data tree
        let data = [];

        let tmpData = [];
        let allTerms = new Set();

        // first iterate trough each dataset and find N neighbors as well as all terms in all datasets
        settings.selections.forEach((selection, index) => {
            // find dataset and create neighborhood data if exists
            let dataset = this._dc._find(selection.dataset);
            if (dataset !== undefined) {
                // build terms vector
                let termsVecObj = dataset.buildTermsVec(selection.term);

                // find nn terms
                let nnObj = dataset.findNeighbors(termsVecObj);

                // drop first (is the term itself) and take N next
                let simsNeighbors = nnObj.distances.slice(1, settings.neighbors + 1);

                // collect only neighbors terms
                let neighbors = new Set(simsNeighbors.map(n => n.t));

                // collect all terms
                neighbors.forEach(n => allTerms.add(n));

                let termsNeighbors = simsNeighbors.map(neighbor => ({
                    term: neighbor.t,
                    value: neighbor.s,
                    isExtendedTerm: false
                }));

                tmpData.push({
                    dataset: dataset,
                    nnObj: nnObj,
                    neighbors: neighbors,
                    termsNeighbors: termsNeighbors,
                    termsNeighborsExtended: []
                })
            }
        });

        // then iterate trough datasets again to find similarity values for all other terms - a datasets neighbors
        tmpData.forEach((tmpObj, index) => {

            if (settings.extendedTerms) {
                // find all additional terms of other datasets BUT filter all our own terms
                // they are either anyway included in NN OR they are the term itself and we want to avoid 1.0 sim
                let ownTermSet = new Set(tmpObj.nnObj.termList);
                let additionalNeighbors = new Set([...allTerms].filter(t => !tmpObj.neighbors.has(t) && !ownTermSet.has(t)));

                // find similarity for all other terms
                let simsAdditional = tmpObj.nnObj.distances.filter(n => additionalNeighbors.has(n.t) && !Number.isNaN(n.s));

                tmpObj.termsNeighborsExtended = simsAdditional.map(neighbor => ({
                    term: neighbor.t,
                    value: neighbor.s,
                    isExtendedTerm: true
                }));
            }

            // calculate quantiles 0.25, 0.5 (median) and 0.75
            let termValuesSorted = tmpObj.termsNeighbors.concat(tmpObj.termsNeighborsExtended).map(t => t.value).sort((a, b) => a - b);
            let q25 = quantile(termValuesSorted, 0.25)
            let q50 = quantile(termValuesSorted, 0.5)
            let q75 = quantile(termValuesSorted, 0.75)

            data.push({
                name: tmpObj.dataset.name,
                termString: tmpObj.nnObj.termString,
                stats: [0, 0, q25, q50, q75],
                terms: tmpObj.termsNeighbors.concat(tmpObj.termsNeighborsExtended)
            });

            console.log(tmpObj.termsNeighbors.concat(tmpObj.termsNeighborsExtended).map(t => t.value));
        });


        this._nd.d = data;
        if (callback)
            callback();
    }
}

// demo data class using backend output of paper reference implementation
export class NeighborhoodDemoData {
  constructor() {
    console.log(demo);

    // Transform big array with duo index to two dimensional map

    let ddatasets = demo['neighbors'].reduce((a, entry) => {

      // console.log(entry);

      // parse demo data file
      let datasetId = entry[0];
      let term = entry[1]
      let value = entry[2]
      let isExtendedTerm = entry[3]
      let termId = entry[4];

      // create entry if not existing yet
      a[datasetId] = a[datasetId] || {}

      a[datasetId][termId] = {
        term: term,
        value: value,
        isExtendedTerm: isExtendedTerm
      }

      return a;
    }, {});

    // Transform two-dimensional maps to two-dimensional arrays (without id)

    // Increasing dataset ids, used to map entries to values
    let datasetIds = Object.keys(ddatasets).sort((a, b) => parseInt(a) > parseInt(b))

    let data = datasetIds.map(datasetId => {
        let dterms = ddatasets[datasetId]
        let termIds = Object.keys(dterms).sort((a, b) => parseInt(a) > parseInt(b))
        let terms = termIds.map(termId => dterms[termId]);

        // Do not know what the original authors were doing/thinking but dicts are not sorted in javascript
        // which means there is no guarantee that the stats dict matches the dataset indexes defined for the terms
        // We will fix this mistake but for now just take some dict entry per index (it will mostly match but not per spec)
        let supposedlyDatasetName= Object.keys(demo['stats'])[datasetId];
        let stats = demo['stats'][supposedlyDatasetName];

        let datasetName = datasetId; // FIXME: should be real dataset name not index...
        datasetName = supposedlyDatasetName; // try this name here instead

        return {
            name: datasetName,
            termString: 'gay',
            stats: stats,
            terms: terms
        }
    });


    this.d = data;
  }

}