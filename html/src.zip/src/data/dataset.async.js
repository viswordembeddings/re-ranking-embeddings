import Worker from './dataset.worker.js';

export class WorkerDatasetCollection {
    constructor() {
        this._worker = new Worker();
        this._datasets = [];
        this._terms = [];
    }

    load(callback) {
        this._worker.postMessage({ action: 'load' });
    }

    list() {
        return this._datasets;
    }

    terms() {
        return this._terms;
    }
}

export class WorkerStatus {
    constructor() {
        this.processing = false;
    }

}

export class WorkerDataProcessor {
    constructor(datasetCollection, neighborhoodData, workerStatus) {
        this._dc = datasetCollection;
        this._nd = neighborhoodData;
        this._status = workerStatus;
        this._processIdCounter = 0;

        let obj = this;
        this._worker = datasetCollection._worker;
        this._worker.onmessage = function (e) {
            const message = e.data;
            console.log('WorkerDataProcessor');
            console.log(message);

            if (message.action === 'datasetUpdate') {
                obj._dc._datasets = message.datasets;
                obj._dc._terms = message.terms;
            } else if(message.action === 'dataUpdate') {
                obj._nd.d = message.data;

                // if the received processId is equal to the last used process id we are done with processing
                if (message.processId >= obj._processIdCounter - 1) {
                    obj._status.processing = false;
                }
            }
        };
    }

    rebuild(hint, settings, callback) {
        this._status.processing = true;

        this._worker.postMessage({
            action: 'rebuild',
            hint: hint,
            settings: settings,
            processId: this._processIdCounter
        })
        this._processIdCounter += 1;
    }
}
