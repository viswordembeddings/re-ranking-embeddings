<template>
<div class="container">
  <div class="row mt-4">
    <div class="col-8">
        <neighborhood-graph-view :data="this.g.data.neighborhood" :settings="this.g.settings.neighborhood"></neighborhood-graph-view>
    </div>
    <div class="col-4">
      <neighborhood-settings-view :status="this.g.status" :datasets="this.g.datasets" :processor="this.g.processor" :settings="this.g.settings.neighborhood"></neighborhood-settings-view>
    </div>
  </div>
</div>
</template>

<script>
import DataTestView from "./ui/DataTestView.vue";
import NeighborhoodGraphView from "./ui/NeighborhoodGraphView.vue";
import NeighborhoodSettingsView from "./ui/NeighborhoodSettingsView.vue";

import {DataProcessor, DatasetCollection, NeighborhoodData, NeighborhoodDemoData} from './data/dataset.js';
import {WorkerDataProcessor, WorkerDatasetCollection, WorkerStatus} from './data/dataset.async.js';
import {NeighborhoodSettings} from './data/settings.js';


const nd = new NeighborhoodData();

//const dsc = new DatasetCollection();
//const dp = new DataProcessor(dsc, nd, ns);

// async version
const dsc = new WorkerDatasetCollection(); // async version
const ws = new WorkerStatus();
const dp = new WorkerDataProcessor(dsc, nd, ws);

dsc.load();

const globalState = {
  status: ws,
  processor: dp,
  datasets: dsc,
  data: {
    neighborhood: nd
  },
  settings: {
    neighborhood: new NeighborhoodSettings()
  }
}

export default {
  name: "App",
  components: {
    DataTestView,
    NeighborhoodGraphView,
    NeighborhoodSettingsView
  },
  data: function () {
    return {
      g: globalState
    }
  }
}
</script>

<style>
.container {
    max-width: 1600px;
}
</style>
