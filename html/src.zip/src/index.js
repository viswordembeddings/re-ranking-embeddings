// Style
import './style.css'

// JS
import Vue from 'vue'
import App from './App.vue'

new Vue({ el: '#main-app', render: h => h(App) });
