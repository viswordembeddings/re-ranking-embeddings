const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const {VueLoaderPlugin} = require("vue-loader");
const {CleanWebpackPlugin} = require('clean-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
    entry: {
        index: './src/index.js'
    },
    plugins: [
        new CleanWebpackPlugin(),
        new HtmlWebpackPlugin({
            template: './src/index.html'
        }),
        new VueLoaderPlugin(),
        new CopyWebpackPlugin({
            patterns: [
                { from: 'static' }
            ]
        })
    ],
    module: {
        rules: [
            {
                test: /\.vue$/,
                exclude: /node_modules/,
                loader: 'vue-loader'
            },
            {
                test: /\.css$/,
                use: [
                    'style-loader', // Adds CSS to the DOM by injecting a `<style>` tag
                    'css-loader' // Interprets `@import` and `url()` like `import/require()` and will resolve them
                ]
            },
            {
                test: /\.worker\.js$/,
                loader: 'worker-loader',
                options: {
                  filename: "[name].js",
                }
            }
        ]
    },
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, '../dist'),
    },
};
