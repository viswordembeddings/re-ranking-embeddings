const {merge} = require('webpack-merge');
const common = require('./webpack.common.js');

module.exports = merge(common, {
    mode: 'development',
    devtool: 'inline-source-map',
    resolve: {
        alias: {
            // Required if we create inline vue components inside of single vue component files
            // https://stackoverflow.com/a/47332729
            vue: 'vue/dist/vue.js'
        },
    },
    devServer: {
        contentBase: './dist',
        disableHostCheck: true
    },
});